angular.module('fenix').controller('loginCtrl', ['$stateParams', '$rootScope', '$scope', 'AuthenticationFactory', '$state','setupFactory','$crypto','$base64', function($stateParams, $rootScope, $scope, AuthenticationFactory, $state, setupFactory, $crypto, $base64) {
        var config = setupFactory.getConfig();
        console.log("loginCtrl");
        $scope.userId="";
        $scope.password="";
        $scope.sndLogin = function() {
        	 console.log("loginCtrl 1");
            if ($scope.userId != undefined && $scope.password != undefined) {
            	//$crypto.encrypt($scope.password, '3m4lk2s12z5cqw6re6g8h9dfjs5b9jv5');
            	//return false;
            	
                AuthenticationFactory.Login($scope.userId, $scope.password, function(response) {
                    if (response.data.success === 'true') {
                    	AuthenticationFactory.SetCredentials($scope.userId, $scope.password, response.data.payload);
                    	 $state.go('dashboard');
                    } else {
                        $scope.error = true;
                        $scope.errorStatus = config.messages.loginError;
                        $scope.loginReqired = false;
                        $state.go('login');
                    }
                });
            } else {
                $scope.error = true;
                $scope.errorStatus = config.messages.loginError;
            }
        };
        
        
        (function initController() {
            // reset login status
            $scope.errorStatus = '';
            $scope.loginReqired = false;
            AuthenticationFactory.ClearCredentials();
        })();
    }]);