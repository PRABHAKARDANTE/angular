angular.module('fenix').controller('appInfoCtrl', ['$stateParams', '$rootScope', '$scope', 'ajaxService','AuthenticationFactory', '$state','setupFactory','$cookieStore', function($stateParams, $rootScope, $scope, ajaxService,AuthenticationFactory, $state, setupFactory,$cookieStore) {
        var config = setupFactory.getConfig(); 
        var userDetails=$cookieStore.get('globals');
        $scope.appInfoPageSelected=true;
        console.log("appInfoCtrl");
      $scope.appList="";
   ajaxService.apicallWithHeaders(config.apiurl+"/getApplications",{},{},"GET").then(function(response){
        	if(response.data.success=="true")
        		{
        		$scope.appList=response.data.payload;
        		}
        	
        },function(error)
        {
        	console.log(error);
        });
}]); 