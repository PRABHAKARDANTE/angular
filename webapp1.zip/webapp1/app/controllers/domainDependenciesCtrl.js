angular.module('fenix').controller('domainDependenciesCtrl', ['$stateParams', '$rootScope', '$scope', 'ajaxService','AuthenticationFactory', '$state','setupFactory','$cookieStore', function($stateParams, $rootScope, $scope, ajaxService,AuthenticationFactory, $state, setupFactory,$cookieStore) {
        var config = setupFactory.getConfig(); 
        var userDetails=$cookieStore.get('globals');
        $scope.appInfoPageSelected=true;
        console.log("domainDependenciesCtrl");
      $scope.domainList="";
   ajaxService.apicallWithHeaders(config.apiurl+"/getDomainDependecies",{},{},"GET").then(function(response){
        	if(response.data.success=="true")
        		{
        		$scope.domainList=response.data.payload;
        		}
        	
        },function(error)
        {
        	console.log(error);
        });
}]); 