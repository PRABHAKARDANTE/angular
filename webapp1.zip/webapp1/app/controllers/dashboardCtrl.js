angular.module('fenix').controller('dashboardCtrl', ['$stateParams', '$rootScope', '$scope', 'AuthenticationFactory', '$state','setupFactory','$crypto','$base64', function($stateParams, $rootScope, $scope, AuthenticationFactory, $state, setupFactory, $crypto, $base64) {
       // var config = setupFactory.getConfig();
	$scope.homePageSelected=true;
	$scope.vinManagement= function()
	{
		//$state.go('vinManagement');
		//$scope.contentUrl = '/vinManagement';
		$scope.homePageSelected=false;
		$scope.vinManagementPageSelected=true;
		$scope.appInfoPageSelected=false;
		$scope.contentUrl='app/views/pages/vinManagement.html';
		console.log("In VinManagement : " + $scope.contentUrl);
	};
	$scope.appInfo= function()
	{
		//$state.go('appInfo');
		$scope.homePageSelected=false;
		$scope.vinManagementPageSelected=false;
		$scope.appInfoPageSelected=true;
		$scope.contentUrl='app/views/pages/appInfo.html';
		console.log("In AppInfo : " + $scope.contentUrl);
	};
       console.log("dashboardCTRL");
    }]);