angular.module('fenix').controller('vinManagementCtrl', ['$stateParams', '$rootScope', '$scope', 'ajaxService','AuthenticationFactory', '$state','setupFactory','$cookieStore', function($stateParams, $rootScope, $scope, ajaxService,AuthenticationFactory, $state, setupFactory,$cookieStore) {
        var config = setupFactory.getConfig(); 
        var userDetails=$cookieStore.get('globals');
        $scope.vinManagementPageSelected=true;
        $scope.userId=userDetails.currentUser.userId;
   console.log("vinManagementCtrl");
   console.log("userId="+$scope.userId);
   
   $scope.vinManagementList="";
   $scope.vinName="";
   $scope.modelYear="";
   $scope.vehicleProgram="";
   $scope.notes="";
   ajaxService.apicallWithHeaders(config.apiurl+"/vins/"+$scope.userId,{},{},"GET").then(function(response){
        	if(response.data.success=="true")
        		{
        		$scope.vinManagementList=response.data.payload;
        		}
        	
        },function(error)
        {
        	console.log(error);
        });
   
   $scope.deleteVin=function(vin){
	   console.log("vin="+vin.vinName);
	   var obj={};
	   obj.userId=$scope.userId;
	   obj.vinName=vin.vinName;
	   console.log("obj="+obj);
	   ajaxService.apicallWithHeaders(config.apiurl+"/vins/delete?userId="+$scope.userId+"&vinName="+vin.vinName,{},{'Content-Type':'form-data'},"DELETE").then(function(response){
       	if(response.data.success=="true")
       		{
       		window.alert(response.data.payload.message);
       		
       		ajaxService.apicallWithHeaders(config.apiurl+"/vins/"+$scope.userId,{},{},"GET").then(function(response){
            	if(response.data.success=="true")
            		{
            		$scope.vinManagementList=response.data.payload;
            		}
            	else if(response.data.success=="false")
            		{
            		$scope.vinManagementList="";
            		}
            	
            },function(error)
            {
            	console.log(error);
            });
       		}
       	
       },function(error)
       {
       	console.log(error);
       });
	   
   };
   
   $scope.saveVin=function(){
	  
       if ($scope.vinName != undefined && $scope.modelYear != undefined && $scope.vehicleProgram != undefined && $scope.notes != undefined) 
       {
    	   var params="userId="+$scope.userId+"&vinName="+$scope.vinName+"&modelYear="+$scope.modelYear+"&vehicleProgram="+$scope.vehicleProgram+"&notes="+$scope.notes;
    	   console.log("params="+params);
    	   ajaxService.apicallWithHeaders(config.apiurl+"/vin/?"+params,{},{},"POST").then(function(response){
    	       	if(response.data.success=="true")
    	       		{
    	       		window.alert(response.data.payload.message);
    	       		angular.element(document.querySelector('#modalCLoseBtn')).click();
    	       		ajaxService.apicallWithHeaders(config.apiurl+"/vins/"+$scope.userId,{},{},"GET").then(function(response){
    	            	if(response.data.success=="true")
    	            		{
    	            		
    	            		$scope.vinManagementList=response.data.payload;
    	            		}
    	            	else if(response.data.success=="false")
    	            		{
    	            		$scope.vinManagementList="";
    	            		}
    	            	
    	            },function(error)
    	            {
    	            	console.log(error);
    	            });
    	       		}
    	       	
    	       },function(error)
    	       {
    	       	console.log(error);
    	       });
    	   
       }    
    	   
       };
}])