angular.module('fenix').filter('dateSuffix', function($filter){
	var suffixes = ["th", "st", "nd", "rd"];
    return function(input) {
		input = input || new Date();
		var dtfilter = $filter('date')(input, 'MMMM - yyyy H:mm');;
		var day = $filter('date')(input, 'dd');
		var relevantDigits = (day < 30) ? day % 20 : day % 30;
		var suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
		return day+suffix+' '+dtfilter;
    };
}).filter('formatDateForDisplay', function($filter){
	return function(input) {
		var datetime = input.split('T');
		var dateArr = datetime[0].split('-');
		var timeformat = datetime[1].split(':');
		var period = "am";
		if(timeformat[0] >= 12){
			timeformat[0] = Number(timeformat[0]) - 12;
			period = "pm";
		}
		return dateArr[1]+"/"+dateArr[2]+"/"+dateArr[0]+" "+timeformat[0]+":"+timeformat[1]+period;
	};
}).filter('objLength', function(){
     return function(input){
     if(!angular.isObject(input)){
          return '0';
      }
     return Object.keys(input).length;
  }
}).filter('capitalize', function() {
    return function(input) {
    	return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    }
}).filter('split', function() {
    return function(input, splitChar, splitIndex) {
        // do some bounds checking here to ensure it has that index
        return input.split(splitChar)[splitIndex];
    }
}).filter('unique', function() {
   return function(collection, keyname) {
	      var output = [], 
	          keys = [];
	      angular.forEach(collection, function(item) {
	          var key = item[keyname];
	          if(keys.indexOf(key) === -1) {
	              keys.push(key);
	              output.push(item);
	          }
	      });
	      return output;
	   };
});