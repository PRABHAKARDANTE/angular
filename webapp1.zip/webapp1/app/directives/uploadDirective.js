angular.module('fenix').directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]).directive('intraVideo', function ($timeout) {
    var k = 0;
    var link = function (scope, element, attrs) {
        scope.datapath = attrs.datapath;
        scope.datatype = attrs.datatype;
        scope.k = k++;
        scope.$watch(function () {
            return attrs.datapath;
        }, function (value) {
            $timeout(function () {
                var video = document.getElementById('intra-video');
                if(video !==  null){
                	var sources = video.getElementsByTagName('source');
                    sources[0].src = attrs.datapath;
                    video.load();
                }
            }, 0, false);
        });
    };
    return {
        //require: 'ngModel',
        restrict: 'E',
        scope: false,
        replace: true,
        template: '<video id="intra-video" width="100%" controls autostart="0"><source src="" type="video/mp4">Your browser does not support HTML5 video.</video>',
        link: link
    }
}).directive('embedSrc', function () {
	return {
	    restrict: 'A',
	    link: function (scope, element, attrs) {
    	var current = element;
    	scope.$watch(function() { return attrs.embedSrc; }, function () {
		var clone = element
              .clone()
              .attr('src', attrs.embedSrc);
        current.replaceWith(clone);
        current = clone;
      });
    }
  };
}).directive('yrInteger', function () {
	return {
		restrict: 'A',
		link: function(scope, element, attrs) {  
			element.on('keypress', function(event) {
				if ( !isIntegerChar() ) 
					event.preventDefault();
				function isIntegerChar() {
					return /[0-9]|-/.test( String.fromCharCode(event.which));
				}
			});         
		}
	};
}).directive('choice', function () {
    return {
        restrict: 'AE',
        templateUrl: 'app/views/templates/choice.html',
        link: function (scope, element, attrs) {
        //plugin bootstrap minus and plus
    	$('.btn-number').click(function(e){
			e.preventDefault();   
			fieldName = $(this).attr('data-field');
			type      = $(this).attr('data-type');
			var input = $("input[name='"+fieldName+"']");
			var currentVal = parseInt(input.val());
			if (!isNaN(currentVal)) {
				if(type == 'minus') {            
					if(currentVal > input.attr('min')) {
						input.val(currentVal - 1).change();
					} 
					if(parseInt(input.val()) == input.attr('min')) {
						$(this).attr('disabled', true);
					}
				} else if(type == 'plus') {
					if(currentVal < input.attr('max')) {
						input.val(currentVal + 1).change();
					}
					if(parseInt(input.val()) == input.attr('max')) {
						$(this).attr('disabled', true);
					}
				}
			} else {
				input.val(0);
			}
    	});
		$('.input-number').focusin(function(){
			$(this).data('oldValue', $(this).val());
		});
		$('.input-number').change(function() {    
		    minValue =  parseInt($(this).attr('min'));
		    maxValue =  parseInt($(this).attr('max'));
		    valueCurrent = parseInt($(this).val());		    
		    name = $(this).attr('name');
		    if(valueCurrent >= minValue) {
		        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
		    } else {
		        alert('Sorry, the minimum value was reached');
		        $(this).val($(this).data('oldValue'));
		    }
		    if(valueCurrent <= maxValue) {
		        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
		    } else {
		        alert('Sorry, the maximum value was reached');
		        $(this).val($(this).data('oldValue'));
		    }
		});
		$(".input-number").keydown(function (e) {
	        // Allow: backspace, delete, tab, escape, enter and .
	        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
	             // Allow: Ctrl+A
	            (e.keyCode == 65 && e.ctrlKey === true) || 
	             // Allow: home, end, left, right
	            (e.keyCode >= 35 && e.keyCode <= 39)) {
	                 // let it happen, don't do anything
	                 return;
	        }
	        // Ensure that it is a number and stop the keypress
	        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
	            e.preventDefault();
	        }
		});
    }    
  };
}).directive('fileBrowser', function() {
    return {
        restrict: 'AE',
        replace: true,
        transclude: true,
        scope: false,
        template:
            '<div class="input-prepend extended-date-picker">'+
                '<input type="button" class="btn" value="browse..." style="width: 20%;">'+
                '<input type="text" readonly class="override" style="width: 40%;">'+
                '<div class="proxied-field-wrap" ng-transclude></div>'+
            '</div>',
        link: function($scope, $element, $attrs, $controller) {
            var button, fileField, proxy;
            fileField = $element.find('[type="file"]').on('change', function() {
                proxy.val(angular.element(this).val());
            });
            proxy = $element.find('[type="text"]').on('click', function() {
                fileField.trigger('click');
            });
            button = $element.find('[type="button"]').on('click', function() {
                fileField.trigger('click');
            });
        }
    };
}).directive('validNumber', function() {
      return {
        require: '?ngModel',
        link: function(scope, element, attrs, ngModelCtrl) {
          if(!ngModelCtrl) {
            return; 
          }
          ngModelCtrl.$parsers.push(function(val) {
            if (angular.isUndefined(val)) {
                var val = '';
            }            
            var clean = val.replace(/[^-0-9\.]/g, '');
            var negativeCheck = clean.split('-');
			var decimalCheck = clean.split('.');
            if(!angular.isUndefined(negativeCheck[1])) {
                negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                clean =negativeCheck[0] + '-' + negativeCheck[1];
                if(negativeCheck[0].length > 0) {
                	clean =negativeCheck[0];
                }                
            }              
            if(!angular.isUndefined(decimalCheck[1])) {
                decimalCheck[1] = decimalCheck[1].slice(0,2);
                clean =decimalCheck[0] + '.' + decimalCheck[1];
            }
            if (val !== clean) {
              ngModelCtrl.$setViewValue(clean);
              ngModelCtrl.$render();
            }
            return clean;
          });
          element.bind('keypress', function(event) {
            if(event.keyCode === 32) {
              event.preventDefault();
            }
          });
        }
      };
}).directive('openselect', function () {
	var showDropdown = function (element) {
		var event;
		event = document.createEvent('MouseEvents');
		event.initMouseEvent('mousedown', true, true, window);
		element.dispatchEvent(event);
	};
	return {
		restrict: 'A',
		scope: {
			'elemento': '@'
		},
		link: function (scope, elem, attrs, ctrl) {
			elem.bind('click', function () {
				var elemento = document.getElementById(scope.elemento);
				console.log(elemento);
				showDropdown(elemento);
			});
		}
	};
}).directive('ngFileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			var model = $parse(attrs.ngFileModel);
			var isMultiple = attrs.multiple;
			var modelSetter = model.assign;
			element.bind('change', function () {
				var values = [];
				angular.forEach(element[0].files, function (item) {
					var value = {
					   // File Name 
						name: item.name,
						//File Size 
						size: item.size,
						//File Type
						type: item.type,
						//File URL to view 
						url: URL.createObjectURL(item),
						// File Input Value 
						_file: item
					};
					values.push(value);
				});
				scope.$apply(function () {
					if (isMultiple) {
						modelSetter(scope, values);
					} else {
						modelSetter(scope, values[0]);
					}
				});
			});
		}
	};
}]);