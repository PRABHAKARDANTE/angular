angular.module('fenix').directive('runTabs', function() {
	return function($scope, $element, $attrs) {
		$element.tabs();
	}
}).directive(
		'digitsOnly',
		function() {
			return {
				require : 'ngModel',
				link : function(scope, element, attr, ngModelAllowNuCtrl) {
					function fromUser(text) {
						if (text) {
							// var transformedInput =
							// text.replace(/(^0$)|([^0-9]\d{0,8}$)/g, '');
							var transformedInput = text.replace(
									/(^0$)|([^0-9\.]\d{0,8}$)/g, '');
							if (transformedInput !== text) {
								ngModelAllowNuCtrl
										.$setViewValue(transformedInput);
								ngModelAllowNuCtrl.$render();
							}
							return transformedInput;
						}
						return undefined;
					}
					ngModelAllowNuCtrl.$parsers.push(fromUser);
				}
			};
		}).directive('numbersOnly', function() {

	return {
		require : 'ngModel',
		link : function(scope, element, attr, ngModelCtrl) {
			function fromUserNumber(text) {
				if (text) {
					var transformedInput = text.replace(/[^0-9]/g, '');

					if (transformedInput !== text) {
						ngModelCtrl.$setViewValue(transformedInput);
						ngModelCtrl.$render();
					}
					return transformedInput;
				}
				return undefined;
			}
			ngModelCtrl.$parsers.push(fromUserNumber);
		}
	};

}).directive('noSpecialChar', function() {
	return {
		require : 'ngModel',
		restrict : 'A',
		link : function(scope, element, attrs, modelCtrl) {
			modelCtrl.$parsers.push(function(inputValue) {
				if (inputValue == null) {
					return '';
				}

				var cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
				if (cleanInputValue != inputValue) {
					modelCtrl.$setViewValue(cleanInputValue);
					modelCtrl.$render();
				}

				return cleanInputValue;
			});
		}
	}
}).directive('alphaNumeric', function() {

	return {
		require : 'ngModel',
		link : function(scope, element, attr, ngModelCtrl) {
			function fromUserNumber(text) {
				if (text) {
					var transformedInput = text.replace(/[^0-9a-zA-Z]/g, '');

					if (transformedInput !== text) {
						ngModelCtrl.$setViewValue(transformedInput);
						ngModelCtrl.$render();
					}
					return transformedInput;
				}
				return undefined;
			}
			ngModelCtrl.$parsers.push(fromUserNumber);
		}
	};

}).directive('alphaOnly', function() {

	return {
		require : 'ngModel',
		link : function(scope, element, attr, ngModelCtrl) {
			function fromUserNumber(text) {
				if (text) {
					var transformedInput = text.replace(/[^a-zA-Z]/g, '');

					if (transformedInput !== text) {
						ngModelCtrl.$setViewValue(transformedInput);
						ngModelCtrl.$render();
					}
					return transformedInput;
				}
				return undefined;
			}
			ngModelCtrl.$parsers.push(fromUserNumber);
		}
	};

}).directive('ngConfirmClick', [ function() {
	return {
		link : function(scope, element, attr) {
			var msg = attr.ngConfirmClick || "Are you sure?";
			var clickAction = attr.confirmedClick;
			element.bind('click', function(event) {
				if (window.confirm(msg)) {
					scope.$eval(clickAction)
				}
			});
		}
	};
} ]).directive("limitTo", [ function() {
	return {
		restrict : "A",
		link : function(scope, elem, attrs) {
			var limit = parseInt(attrs.limitTo);
			angular.element(elem).on("keypress", function(e) {
				this.value = this.value.substring(0, limit - 1);
			});
		}
	}
} ]);
