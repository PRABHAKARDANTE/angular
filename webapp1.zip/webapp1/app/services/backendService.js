angular.module('fenix').service(
        "backendService",
        function ($rootScope, $q, setupFactory, ajaxService, $timeout) {
            var backendAPI;
            var backendHeaders = {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'basic_auth': 'intralox'
            }
            return({
                authentication: authentication,
//                saveProcessedInfo: saveProcessedInfo,
//                getHistory: getHistory
            });

            function authentication() {
                var config = setupFactory.getConfig();
                var APIUrl = config.apiurl + config.backendAuthentication;
                var request = ajaxService.ajaxHttp(APIUrl, {}, backendHeaders,'post');
                return(request.then(handleSuccess, handleError));
            }

//            function saveProcessedInfo(runSummary) {
//              
//            }
//
//            function getHistory(pageNumber, numberOfRecords) {
//               
//            }

            function handleError(response) {

                return($q.reject(response));
            }
            function handleSuccess(response) {
                if (response.responseCode == 1) {
                    $q.reject(response.errors);
                } else {
                    return (response.responseData);
                }
            }
        }
);