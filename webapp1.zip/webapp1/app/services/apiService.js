angular.module('fenix').service(
        "apiService",
        function($rootScope, $q, setupFactory, ajaxService, $timeout) {
            return({
                callOptimizationApi: callOptimizationApi,
                optimizationResultsApi: optimizationResultsApi
            });

            function callOptimizationApi(OptimizationObj) {
                var def = $q.defer();
                var config = setupFactory.getConfig();
                var url = config.apiurl + config.optimizationurl;
                var headerObj = {
                    'Content-Type': 'application/json',
                    'x-access-token': $rootScope.apiToken
                };
                ajaxService.ajaxHttp(url, OptimizationObj, headerObj).then(function(result) {
                    if (Object.keys(result).length > 0) {
                        def.resolve(result);
                    }
                    else {
                        def.reject(result);
                    }
                }, function(error) {
                    def.reject(error);
                });
                return def.promise;
            };

            function optimizationResultsApi(runId) {
                var def = $q.defer();
                var config = setupFactory.getConfig();
                var url = config.apiurl + config.optimizationResultsurl.replace('${RunId}', runId);
                var headerObj = {
                    'Content-Type': 'application/json',
                    'x-access-token': $rootScope.apiToken
                };
                ajaxService.ajaxHttp(url, {}, headerObj, 'get').then(function(result) {
                    if (Object.keys(result).length > 0) {
                        def.resolve(result);
                    }
                    else {

                        def.reject(result);
                    }
                }, function(error) {
                    def.reject(error);
                });
                return def.promise;
            };
        }
);