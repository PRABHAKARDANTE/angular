angular.module('fenix').service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function(file, uploadUrl, type, basicAuth, issuedAt, callback){
        var fd = new FormData();
        fd.append('pdfFile', file);
        fd.append('pdfType', type);
        $http.post(uploadUrl, fd, {transformRequest: angular.identity,headers: {'Content-Type': undefined,'basic-auth': basicAuth,'issued_at':issuedAt}}).then(function(response) {
            callback(response);
        }, function(res) {
            callback(res);
        });
    };
    this.uploadVideoFileToUrl = function(file, uploadUrl, callback){
        var fd = new FormData();
        fd.append('videoFile', file);
        $http.post(uploadUrl, fd, {transformRequest: angular.identity,headers: {'Content-Type': undefined,'basic-auth': 'intralox','issued_at':''}}).then(function(response) {
            callback(response);
        }, function(res) {
            callback(res);
        });
    };
    this.uploadImageFileToUrl = function(file, uploadUrl, callback){
        var fd = new FormData();
        fd.append('imageFile', file);
        $http.post(uploadUrl, fd, {transformRequest: angular.identity,headers: {'Content-Type': undefined,'basic-auth': 'intralox','issued_at':''}}).then(function(response) {
            callback(response);
        }, function(res) {
            callback(res);
        });
    };
    this.uploadFileToXlsUrl = function(file, uploadUrl, callback){
        var fd = new FormData();
        fd.append('xlsx', file);
        $http.post(uploadUrl, fd, {transformRequest: angular.identity,headers: {'Content-Type': undefined,'basic-auth': 'intralox'}}).then(function(response) {
            callback(response);
        }, function(res) {
            callback(res);
        });
    };
}]);