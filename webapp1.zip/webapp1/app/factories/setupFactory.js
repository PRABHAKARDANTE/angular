angular.module('fenix').factory('setupFactory', function(ajaxService, $q) {

    var factory = {};
    var config = {};
    factory.getSetup = function() {
        var def = $q.defer();
        ajaxService.getSetup().then(function(res) {
            if (Object.keys(res).length > 0) {
                config = res;
                def.resolve(config);
            } else {
                def.reject(false);
            }

        });
        return def.promise;
    };

    factory.getConfig = function() {
        return config;
    };
    
    return factory;
});