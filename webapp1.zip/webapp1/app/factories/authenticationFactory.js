angular.module('fenix').factory('AuthenticationFactory', ['$http', '$cookieStore', '$rootScope', 'setupFactory', function($http, $cookieStore, $rootScope, setupFactory) {
        var service = {};

        service.Login = Login;
        service.SetCredentials = SetCredentials;
        service.ClearCredentials = ClearCredentials;

        return service;

        function Login(userId, password, callback) {
            var config = setupFactory.getConfig();
            var backendHeaders = {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            var httpData = {"userId": userId, "password": password};

            var request = $http({
                method: 'post',
                headers: backendHeaders,
                url: config.apiurl + '/login',
                data: httpData
            });

            request.then(function(response) {
                callback(response);
            }, function(res) {
                callback(res);
            });
        }
        
        function SetCredentials(userId, password, userDetails) {
            $rootScope.globals = {
                currentUser: {
                	userId: userId
                	
                }
            };
            $cookieStore.put('globals', $rootScope.globals);
        } 
        function ClearCredentials() {
            $rootScope.globals = {};
            $cookieStore.remove('globals');
        }
        
    }]);