angular.module('fenix').factory('uploadFactory', ['$q', '$timeout', function($q, $timeout) {
	var runSummary = {};
    return {
        readFile : readFile,
        validateFile : validateFile,
        setRunSummary : setRunSummary,
        getRunSummary : getRunSummary
    };
    function readFile(fileBlob) {
        /**
         * Using the file reader, returns the uploaded
         * file in Binary format
         *
         * @params {Object} File object of the uploaded file
         *
         * @returns {binary} Binary data of the uploaded file
         *
         */
        var deferred = $q.defer();
        var reader = new FileReader();
        
        reader.onload = function (e) { 
            var data = e.target.result;
            deferred.resolve(data);
        };
        
        reader.onerror = function () { 
            deferred.reject(); 
        };
        
        reader.readAsBinaryString(fileBlob);

        return deferred.promise;
    }
    
    //validating row data
    function validateRow (rowdata, sheetName) {
        if (sheetName === "WorkItems" && rowdata.length) {
            return (validateWorkItemsID(rowdata[0]) && validateLatitudeLongitude(rowdata[4], rowdata[5]));
        } 
        else if(sheetName === "Worker" && rowdata.length) {
            return (validateWorkItemsID(rowdata[0]) && validateLatitudeLongitude(rowdata[4], rowdata[5]) && dateValidation(rowdata[9], rowdata[10]));
        }
        return false;
    }
    //validing work items/worker ID
    function validateWorkItemsID(id){
        return (id !== undefined);
    }
    function validateLatitudeLongitude(latitude,longitude) {
        return !(latitude === undefined || longitude === undefined);
    }
    
    //validate the End date/time must be after the Start date/time.
    function dateValidation(startdate, enddate) {
        
        if (Date.parse(dateFormatValidation(startdate)) < Date.parse(dateFormatValidation(enddate))) {
            return true;
        } 
        return false;
    }
    
    function dateFormatValidation(inputdate) {
        var datetime = inputdate.split(' ');
        var dateArr = datetime[0].split('/');
        var timeformat = datetime[1].replace("am", ":am");
        timeformat = timeformat.replace("pm", ":pm");
        var timeArr = timeformat.split(':');
        if(timeArr[2] === 'pm'){
            timeArr[0] = Number(timeArr[0]) + 12;
        }
        return new Date(dateArr[2], dateArr[0], dateArr[1], timeArr[0], timeArr[1]);
    }
    
    //Date format for API Request
    function formatApiDate(inputdate) {

        var datetime = inputdate.split(' ');
        var dateArr = datetime[0].split('/');
        var timeformat = datetime[1].replace("am", ":am");
        timeformat = timeformat.replace("pm", ":pm");
        var timeArr = timeformat.split(':');
        if(timeArr[2] === 'pm'){
            timeArr[0] = Number(timeArr[0]) + 12;
        }
        return dateArr[2]+"-"+dateArr[0]+"-"+dateArr[1]+"T"+timeArr[0]+":"+timeArr[1]+":00.000Z";

    }
    //form the worker/workitems object
    function formatObj(row, sheetname) {
        var skills=[], timeConstraintsArr=[];
             if (sheetname === "WorkItems") {
                 for(var skillscount=2;skillscount<4;skillscount++) {
                     if (row[skillscount] != undefined && row[skillscount].replace(/ /g,"") != '') {
                		 skills.push({"Id":row[skillscount]});
                	 }
                  }
                  
                  
                  
                  var rowObj = {
                            "Id":row[0],
                            "Location":{
                                    "Address":{
                                            "AddrType":"10",
                                            "PostalCode":"23512",
                                            "Lat":parseFloat(row[4]),
                                            "Lon":parseFloat(row[5])
                                            }
                            },
                            "WorkType":{
                                   "Dur":parseInt(row[1]),
                                   "Skills":skills
                               },
                            "Type":"JOB"
                            };
                     
              }
             else if (sheetname === "Worker") {
                  for(var skillscount=4; skillscount<9; skillscount++) {
                        if (row[skillscount] !== undefined) {
                                skills.push({"Id" : row[skillscount]});
                        }
                  }
                  //All the dates format update to JSON
                  for(var startAndEndDates=9; startAndEndDates<15; startAndEndDates+=2) {
                            timeConstraintsArr.push({
                            "Type":30,
                            "Period": {
                                "Start": formatApiDate(row[startAndEndDates]),
                                "End": formatApiDate(row[startAndEndDates+1])
                             }
                        });
                  }
                  var rowObj = {
                        "Id":row[0],
                        "Addresses":[{"Lat":parseFloat(row[2]),"Lon":parseFloat(row[3]),"AddrType":row[1]}],
                        "Skills":skills,
                        "TimeConstraints":timeConstraintsArr
                    };
              }
                        
        return rowObj;
    }
    function validateFile(data) {
        /**
         * Validates the uploaded for necessary field validations
         *
         * @param {binary} data: Binary data of the uploaded file
         *
         * @returns {Object} Json object of the uploaded file
         */
        var deferred = $q.defer(),				
        wb = XLS.read(data, {
        	type: 'binary'
        }),
        error = "",   
        errorWorkItemsRecords = [],
        errorWorkersRecords = [],
        workersObj = [],
        workItemsObj = [], 
        dataArr = {}, 
        validationStatus = true,
        skillsMatrix = {};
        runSummary = {};
        wb.SheetNames.forEach(function(sheetName) {
            /**
             * Loop through each sheet
             *
             * @param {string} sheetName: Name of the sheet
             *
             */
            var sCSV = XLS.utils.make_csv(wb.Sheets[sheetName]),
                data = XLS.utils.sheet_to_json(wb.Sheets[sheetName], {header:1});   

            if (sheetName === "WorkItems") {
                //Loop through each row
                $.each(data, function( indexR, valueR ) {
                    if(indexR == 0) {
                        return;
                    } 
                    if(validateRow(data[indexR],"WorkItems") && data[indexR][0] !== 'Id' && data[indexR][0] !== '') {
                         
                        //Skill metix prepation
                        if(data[indexR][3] !== undefined && data[indexR][3].replace(/ /g,"") != '') {
                        	var ind = data[indexR][2].replace(/ /g,"") + "," + data[indexR][3].replace(/ /g,"");
                        	var revInd = data[indexR][3].replace(/ /g,"") + "," + data[indexR][2].replace(/ /g,"");
                            if(skillsMatrix[ind]) {
                                skillsMatrix[ind] = skillsMatrix[ind] + 1;
                            }
                            else if (skillsMatrix[revInd]) {
                            	skillsMatrix[revInd] = skillsMatrix[revInd] + 1;
                            }
                            else {
                                skillsMatrix[ind] = 1;
                            }
                        }
                        else {
                            if(skillsMatrix[data[indexR][2]]){
                                skillsMatrix[data[indexR][2]] = skillsMatrix[data[indexR][2]] + 1;
                            }
                            else {
                                skillsMatrix[data[indexR][2]] = 1;
                            }
                        }
                  
                        var workerItemsDataArr = formatObj(data[indexR],"WorkItems");
                        workItemsObj.push(workerItemsDataArr);
                         
                    }
                    else {
                       if(data[indexR].length) {
                            errorWorkItemsRecords.push(data[indexR]);
                       }
                       validationStatus = false;
                    }
                    
                  });
            }
            else if (sheetName === "Worker") {
                //Loop through each row
                $.each(data, function( indexR, valueR ) {
                    if(indexR==0) {
                        return;
                    } 
                    if(validateRow(data[indexR],"Worker") && data[indexR][0]!=='Id' && data[indexR][0]!=='') {
                        
                    	var workerDataArr = formatObj(data[indexR],"Worker");
                        workersObj.push(workerDataArr);
                    }
                    else{
                        if(data[indexR].length) {
                            errorWorkersRecords.push(data[indexR]);
                        }
                        validationStatus = false;
                    }
                    
                });
            }
           
        });

        dataArr.validationStatus = validationStatus;
        dataArr.Workers = workersObj;
        dataArr.WorkItems = workItemsObj;
        dataArr.skillsMatrix = skillsMatrix;
        dataArr.errorWorkItemsRecords = errorWorkItemsRecords;
        dataArr.errorWorkersRecords = errorWorkersRecords;
        
        return dataArr;
    }
    
    function getRunSummary() {
    	return runSummary;
    }
    
    function setRunSummary(runObj) {
    	runSummary = angular.extend(getRunSummary(), runObj);
    	
    }

}]);