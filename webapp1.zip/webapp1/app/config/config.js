angular.module('fenix').config(['$httpProvider','$cryptoProvider', function ($httpProvider, $cryptoProvider) {
	delete $httpProvider.defaults.headers.common['X-Requested-With']; //Fixes cross domain requests
    $httpProvider.defaults.headers.common['Cache-Control'] = 'no-cache';
	$httpProvider.defaults.cache = false;
	if (!$httpProvider.defaults.headers.get) {
	    $httpProvider.defaults.headers.get = {};
	}
	$httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
	//$cryptoProvider.setCryptographyKey('H7ujn9Ef82K0i3uZ');
}]);
