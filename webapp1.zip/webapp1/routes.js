angular.module('fenix').config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('login');
    $stateProvider
            .state('login', {
                url: '/login',
                templateUrl: 'app/views/pages/login.html',
                controller: 'loginCtrl'
            })
             .state('dashboard', {
                url: '/dashboard',
                templateUrl: 'app/views/pages/dashboard.html',
                controller: 'dashboardCtrl'
            })
             .state('vinManagement', {
                url: '/vinManagement',
                templateUrl: 'app/views/pages/vinManagement.html',
                controller: 'vinManagementCtrl'
            })
            .state('appInfo', {
                url: '/appInfo',
                templateUrl: 'app/views/pages/appInfo.html',
                controller: 'appInfoCtrl'
            })
            . .state('domainDependencies', {
                url: '/domainDependencies',
                templateUrl: 'app/views/pages/domainDependencies.html',
                controller: 'domainDependenciesCtrl'
            })
});