angular.module('fenix', ['ui.router', 'ngCookies', 'ngSanitize', 'colorpicker.module', 'textAngular', 'angularUtils.directives.dirPagination', 'multipleSelect', 'chart.js','mdo-angular-cryptography','base64']).run(function($rootScope, $state, setupFactory, ajaxService, backendService, $cookies, $stateParams, $cookieStore, $location, $window) {
    $rootScope.msg = {};
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;
    $rootScope.apiToken = '';
    setupFactory.getSetup()
			    .then(function () {
			        return backendService.authentication();
			    });
    $rootScope.globals = $cookieStore.get('globals') || {};
    
    $rootScope.$on('$locationChangeStart', function (event, next, current) {
    	   	
    });
    
    $rootScope.$on('$locationChangeSuccess', function() {
        $rootScope.actualLocation = $location.path();
    });
    
    $rootScope.$watch(function() { return $location.path() }, function(newLocation, oldLocation) {
    	  		
    }); 
});